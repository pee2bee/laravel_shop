<footer class="footer">
    <div class="container">
        <p class="float-left">
            由 <a href="https://leo108.com" target="_blank">Leo</a> 设计和编码 <span style="color: #e27575;font-size: 14px;">❤</span>
        </p>

        <p class="float-right"><a href="mailto:name@email.com">联系我们</a></p>
    </div>
</footer>
<?php /**PATH D:\Program\www\laravel_shop\resources\views/layouts/_footer.blade.php ENDPATH**/ ?>