<?php $__env->startSection('title','收藏列表'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-10 offset-lg-1">
      <div class="card">
        <div class="card-header">我的收藏 - 共<?php echo e($total, false); ?>条</div>
        <div class="card-body">
          <!-- 筛选组件开始 -->
          <form action="<?php echo e(route('products.favorites'), false); ?>" class="search-form">
            <div class="form-row">
              <div class="col-md-9">
                <div class="form-row">
                  <div class="col-auto"><input type="text" class="form-control form-control-sm" name="search"
                                               placeholder="搜索"></div>
                  <div class="col-auto">
                    <button class="btn btn-primary btn-sm">搜索</button>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <!-- 筛选组件结束 -->

          <div class="row products-list">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="col-3 product-item">
                <div class="product-content">
                  <a href="<?php echo e(route('products.show',['product'=>$product->id]), false); ?>">
                    <div class="top">
                      <div class="img"><img src="<?php echo e(asset("storage/$product->image"), false); ?>" alt=""></div>
                      <div class="price"><b>￥</b><?php echo e($product->price, false); ?></div>
                      <div class="title"><?php echo e($product->title, false); ?></div>
                    </div>
                  </a>
                  <div class="bottom">
                    <div class="sold_count">销量 <span><?php echo e($product->sold_count, false); ?>笔</span></div>
                    <div class="review_count">浏览 <span><?php echo e($product->view_count, false); ?></span></div>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="float-right"><?php echo e($products->appends($filters)->render(), false); ?></div>  <!-- 只需要添加这一行 -->
        </div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
      var filters = <?php echo json_encode($filters); ?>

      $(document).ready(function () {
          //保留用户搜索和排序条件
          $('.search-form input[name=search]').val(filters.search)

          //按钮点击提交表单
          $('.search-form button').click(function () {
              $('.search-form').submit()
          })
      })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/products/favorites.blade.php ENDPATH**/ ?>