<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content=<?php echo e(csrf_token()); ?>>
    <title><?php echo $__env->yieldContent('title','Laravel_Shop'); ?></title>
    
    <link href="<?php echo e(mix('css/app.css')); ?>"rel="stylesheet">
</head>
<body>
    <div id="app" class="<?php echo e(route_class()); ?>-page">
        <?php echo $__env->make('layouts._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('layouts._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\Program\www\laravel_shop\resources\views/layouts/app.blade.php ENDPATH**/ ?>