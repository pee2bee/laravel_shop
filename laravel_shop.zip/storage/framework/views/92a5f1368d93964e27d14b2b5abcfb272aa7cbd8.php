<?php $__env->startSection('title', '购物车'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-8 offset-lg-2">
    <div class="card">
      <div class="card-header"><h2>购物车</h2></div>
      <div class="card-body">
        <table class="table table-striped">
          <thead>
          <tr>
            <th><input type="checkbox" id="select-all"></th>
            <th>商品信息</th>
            <th>单价</th>
            <th>数量</th>
            <th>操作</th>
          </tr>
          </thead>
          <tbody class="product_list">
          <?php $__currentLoopData = $cardItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr data-id="<?php echo e($item->productSku->id, false); ?>">
              <td>
                <input type="checkbox" name="select" value="<?php echo e($item->productSku->id, false); ?>" <?php echo e($item->productSku->product->on_sale ? 'checked' : 'disabled', false); ?>>
              </td>
              <td class="product_info">
                <div class="preview">
                  <a target="_blank" href="<?php echo e(route('products.show', [$item->productSku->product_id]), false); ?>">
                    <img src="<?php echo e($item->productSku->product->image_url, false); ?>">
                  </a>
                </div>
                <div <?php if(!$item->productSku->product->on_sale): ?> class="not_on_sale" <?php endif; ?>>
              <span class="product_title">
                <a target="_blank" href="<?php echo e(route('products.show', [$item->productSku->product_id]), false); ?>"><?php echo e($item->productSku->product->title, false); ?></a>
              </span>
                  <span class="sku_title"><?php echo e($item->productSku->title, false); ?></span>
                  <?php if(!$item->productSku->product->on_sale): ?>
                    <span class="warning">该商品已下架</span>
                  <?php endif; ?>
                </div>
              </td>
              <td><span class="price">￥<?php echo e($item->productSku->price, false); ?></span></td>
              <td>
                <input type="text" class="form-control form-control-sm amount" <?php if(!$item->productSku->product->on_sale): ?> disabled <?php endif; ?> name="amount" value="<?php echo e($item->amount, false); ?>">
              </td>
              <td>
                <button class="btn btn-sm btn-danger btn-remove">移除</button>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/users/cart.blade.php ENDPATH**/ ?>
