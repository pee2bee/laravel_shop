

<?php $__env->startSection('title','收货地址列表'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row <?php echo e(route_class(), false); ?>">
    <div class="col-md-10 offset-md-1">
      <div class="card">
        <div class="card-header"><h2 class="text-center">收货地址列表</h2></div>
        <div class="card-body">
          <a class="btn btn-primary" href="<?php echo e(route('addresses.create'), false); ?>">添加地址</a>
          <table class="table">
            <thead>
            <tr>
              <th>收货人</th>
              <th>地址</th>
              <th>邮编</th>
              <th>电话</th>
              <th>操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if(!count($addresses)): ?>
              <tr>
                <td class="text-center" colspan="5">
                  <a class="btn btn-primary" href="<?php echo e(route('addresses.create'), false); ?>">
                    还没有收货地址请添加收货地址哦！
                  </a>
                </td>
              </tr>
            <?php endif; ?>
            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($address->contact_name, false); ?></td>
                <td><?php echo e($address->full_address, false); ?></td>
                <td><?php echo e($address->zipcode, false); ?></td>
                <td><?php echo e($address->contact_phone, false); ?></td>
                <td>
                  <a href="<?php echo e(route('addresses.edit', $address->id), false); ?>" class="btn btn-primary">修改</a>
                  <button class="btn btn-danger btn-del-address" type="button" data-id="<?php echo e($address->id, false); ?>">删除</button>

                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
      $(document).ready(function () {
          $('.btn-del-address').click(function () {
              var id = $(this).data('id')
              swal({
                  title: "确认删除该地址？",
                  icon: 'warning',
                  buttons: ['取消', '确定'],
                  dangerMode: true
              }).then(function (willDelete) {
                  //确认为true 取消为false
                  if (!willDelete) {
                      return
                  }
                  axios.delete('addresses/' + id).then(function (data) {
                      swal({
                          title: "删除成功",
                          icon: "success"
                      }).then(function () {
                          //重载页面
                          location.reload()
                      })
                  })
              })
          })
      })
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/users/addresses.blade.php ENDPATH**/ ?>