<?php $__env->startSection('title','发生错误'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-8 offset-lg-2">
      <div class="card">
        <div class="header text-center"><h2>发生错误</h2></div>
        <div class="card-body">

          <p class="card-text "><?php echo e($msg, false); ?></p>

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/pages/error.blade.php ENDPATH**/ ?>