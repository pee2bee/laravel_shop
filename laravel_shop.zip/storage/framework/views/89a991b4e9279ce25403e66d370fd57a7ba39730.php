
<?php $__env->startSection('title','操作成功'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-8 offset-lg-2">
      <div class="card">
        <div class="header text-center"><h2>操作成功</h2></div>
        <div class="card-body">


          <div class="card-body text-center">
            <h3><?php echo e($msg, false); ?></h3>
            <a class="btn btn-primary" href="<?php echo e(route('root'), false); ?>">返回首页</a>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/pages/success.blade.php ENDPATH**/ ?>