<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/Code/laravel_shop/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>