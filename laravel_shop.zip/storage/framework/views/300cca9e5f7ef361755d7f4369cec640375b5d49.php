<div class="box box-info">
  <div class="box-header with-border">
    <h3 class="box-title">订单流水号：<?php echo e($order->no, false); ?></h3>
    <div class="box-tools">
      <div class="btn-group float-right" style="margin-right: 10px">
        <a href="<?php echo e(route('admin.orders.index'), false); ?>" class="btn btn-sm btn-default"><i class="fa fa-list"></i> 列表</a>
      </div>
    </div>
  </div>
  <div class="box-body">
    <table class="table table-bordered">
      <tbody>
      <tr>
        <td>买家：</td>
        <td><?php echo e($order->user->name, false); ?></td>
        <td>支付时间：</td>
        <td><?php echo e($order->paid_at ? $order->paid_at->format('Y-m-d H:i') : '未支付', false); ?></td>
      </tr>
      <tr>
        <td>支付方式：</td>
        <td><?php echo e($order->payment_method, false); ?></td>
        <td>支付渠道单号：</td>
        <td><?php echo e($order->payment_no, false); ?></td>
      </tr>
      <tr>
        <td>收货地址</td>
        <td
          colspan="3"><?php echo e($order->address['address'], false); ?> <?php echo e($order->address['zipcode'], false); ?>

          <?php echo e($order->address['contact_name'], false); ?> <?php echo e($order->address['contact_phone'], false); ?></td>
      </tr>
      <tr>
        <td rowspan="<?php echo e($order->items->count() + 1, false); ?>">商品列表</td>
        <td>商品名称</td>
        <td>单价</td>
        <td>数量</td>
      </tr>
      <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($item->product->title, false); ?> <?php echo e($item->productSku->title, false); ?></td>
          <td>￥<?php echo e($item->price, false); ?></td>
          <td><?php echo e($item->amount, false); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td>订单金额：</td>
        <td colspan="3">￥<?php echo e($order->total_amount, false); ?></td>
      </tr>
      
      <?php if($order->paid_at): ?>
        <tr>
          <td>发货状态：</td>
          <td><?php echo e(\App\Models\Order::$shipStatusMap[$order->ship_status], false); ?></td>
        </tr>
        <tr>
          <td>退款状态:</td>
          <td><?php echo e(\App\Models\Order::$refundStatusMap[$order->refund_status], false); ?></td>
          <?php if($order->refund_status != \App\Models\Order::REFUND_STATUS_PENDING): ?>
            <td>
              退款理由： <?php echo e($order->extra['refund_reason'], false); ?>

            </td>
          <?php endif; ?>
          
          <?php if($order->refund_status === \App\Models\Order::REFUND_STATUS_APPLIED): ?>
            <td>
              <button class="btn btn-sm btn-success" id="btn-refund-agree">同意</button>
              <button class="btn btn-sm btn-danger" id="btn-refund-disagree">不同意</button>
            </td>
            <td></td>
          <?php endif; ?>
        </tr>
        
        <?php if($order->ship_status === \App\Models\Order::SHIP_STATUS_PENDING
        && $order->refund_status != \App\Models\Order::REFUND_STATUS_SUCCESS): ?>
          <tr>
            <td colspan="4">
              <form action="<?php echo e(route('admin.orders.ship',[$order->id]), false); ?>" method="post">

                <?php echo e(csrf_field(), false); ?>

                <div class="form-group <?php echo e($errors->has('express_company') ? 'has-error' : '', false); ?>">
                  <label for="express_company" class="control-label">物流公司</label>
                  <input type="text" id="express_company" name="express_company" value="" class="form-control"
                         placeholder="输入物流公司">
                  <?php if($errors->has('express_company')): ?>
                    <?php $__currentLoopData = $errors->get('express_company'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <span class="help-block"><?php echo e($msg, false); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </div>
                <div class="form-group <?php echo e($errors->has('express_no') ? 'has-error' : '', false); ?>">
                  <label for="express_no" class="control-label">物流单号</label>
                  <input type="text" id="express_no" name="express_no" value="" class="form-control"
                         placeholder="输入物流单号">
                  <?php if($errors->has('express_no')): ?>
                    <?php $__currentLoopData = $errors->get('express_no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <span class="help-block"><?php echo e($msg, false); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-success" id="ship-btn">发货</button>
              </form>
            </td>
          </tr>

        <?php else: ?>
          
          <tr>
            <td>物流公司:</td>
            <td><?php echo e($order->ship_data['express_company'], false); ?></td>
            <td>物流单号:</td>
            <td><?php echo e($order->ship_data['express_no'], false); ?></td>
          </tr>
        <?php endif; ?>

      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
    $(document).ready(function () {
        $('#btn-refund-disagree').click(function () {
            // Laravel-Admin 使用的 SweetAlert 版本与我们在前台使用的版本不一样，因此参数也不太一样
            swal({
                title: '输入拒绝退款理由',
                input: 'text',
                showCancelButton: true,
                confirmButtonText: "确认",
                cancelButtonText: "取消",
                showLoaderOnConfirm: true,
                preConfirm: function (inputValue) {
                    if (!inputValue) {
                        swal('理由不能为空', '', 'error')
                        return false;
                    }
                    // Laravel-Admin 没有 axios，使用 jQuery 的 ajax 方法来请求
                    return $.ajax({
                        url: '<?php echo e(route('admin.orders.disagree_refund', [$order->id]), false); ?>',
                        type: 'POST',
                        data: JSON.stringify({   // 将请求变成 JSON 字符串
                            agree: false,  // 拒绝申请
                            reason: inputValue,
                            // 带上 CSRF Token
                            // Laravel-Admin 页面里可以通过 LA.token 获得 CSRF Token
                            _token: LA.token,
                        }),
                        contentType: 'application/json',  // 请求的数据格式为 JSON
                    });
                },
                allowOutsideClick: false
            }).then(function (ret) {
                // 如果用户点击了『取消』按钮，则不做任何操作
                if (ret.dismiss === 'cancel') {
                    return;
                }
                swal({
                    title: '操作成功',
                    type: 'success'
                }).then(function () {
                    // 用户点击 swal 上的按钮时刷新页面
                    location.reload();
                });
            });
        });
        $('#btn-refund-agree').click(function () {
            swal({
                title: "同意退款，资金会直接退回给用户",
                confirmButtonText: "确认",
                cancelButtonText: "取消",
                showCancelButton: true,
                preConfirm: function () {

                    // Laravel-Admin 没有 axios，使用 jQuery 的 ajax 方法来请求
                    return $.ajax({
                        url: '<?php echo e(route('admin.orders.agree_refund', [$order->id]), false); ?>',
                        type: 'POST',
                        data: JSON.stringify({   // 将请求变成 JSON 字符串
                            // 带上 CSRF Token
                            // Laravel-Admin 页面里可以通过 LA.token 获得 CSRF Token
                            _token: LA.token,
                        }),
                        contentType: 'application/json',  // 请求的数据格式为 JSON
                    });
                },
            }).then(function (ret) {
                // 如果用户点击了『取消』按钮，则不做任何操作
                if (ret.dismiss === 'cancel') {
                    return;
                }
                swal({
                    title: '操作成功',
                    type: 'success'
                }).then(function () {
                    // 用户点击 swal 上的按钮时刷新页面
                    location.reload();
                });
            });
        })
    })


</script>
<?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/admin/orders/show.blade.php ENDPATH**/ ?>