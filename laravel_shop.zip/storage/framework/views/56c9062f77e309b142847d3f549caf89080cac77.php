<footer class="page-footer">
  <div class="container">
    <p class="float-left">
      基于 <a href="https://laravel.com" target="_blank">laravel框架</a> 设计

    </p>

    <p class="float-right"><a href="2529538366@qq.com">联系我们</a></p>
  </div>
</footer>
<?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/layouts/_footer.blade.php ENDPATH**/ ?>