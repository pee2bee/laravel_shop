[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/vagrant/Code/laravel_shop/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>