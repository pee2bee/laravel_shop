<?php $__env->startSection('title', '购物车'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-8 offset-lg-2">
      <div class="card">
        <div class="card-header"><h2>购物车</h2></div>
        <div class="card-body">
          <?php if(count($cartItems)): ?>
            <table class="table table-striped">
              <thead>
              <tr>
                <th><input type="checkbox" id="select-all"></th>
                <th>商品信息</th>
                <th>单价</th>
                <th>数量</th>
                <th>操作</th>
              </tr>
              </thead>
              <tbody class="product_list">
              <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-id="<?php echo e($item->product_sku_id, false); ?>">
                  <td>
                    <input type="checkbox" name="select"
                           value="<?php echo e($item->productSku->id, false); ?>" <?php echo e($item->productSku->product->on_sale ? 'checked' : 'disabled', false); ?>>
                  </td>
                  <td class="product_info">
                    <div class="preview">
                      <a target="_blank" href="<?php echo e(route('products.show', [$item->productSku->product_id]), false); ?>">
                        <img src="<?php echo e($item->productSku->product->image_url, false); ?>">
                      </a>
                    </div>
                    <div <?php if(!$item->productSku->product->on_sale): ?> class="not_on_sale" <?php endif; ?>>
              <span class="product_title">
                <a target="_blank"
                   href="<?php echo e(route('products.show', [$item->productSku->product_id]), false); ?>"><?php echo e($item->productSku->product->title, false); ?></a>
              </span>
                      <span class="sku_title"><?php echo e($item->productSku->title, false); ?></span>
                      <?php if(!$item->productSku->product->on_sale): ?>
                        <span class="warning">该商品已下架</span>
                      <?php endif; ?>
                    </div>
                  </td>
                  <td><span class="price">￥<?php echo e($item->productSku->price, false); ?></span></td>
                  <td>
                    <input type="text" class="form-control form-control-sm amount"
                           <?php if(!$item->productSku->product->on_sale): ?> disabled <?php endif; ?> name="amount"
                           value="<?php echo e($item->amount, false); ?>">
                  </td>
                  <td>
                    <button class="btn btn-sm btn-danger btn-remove">移除</button>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          <?php else: ?>
            <div class="no-cartItem">购物车为空</div>
          <?php endif; ?>

          <form class="form-horizontal" role="form" id="order-form">
            <div class="form-group row">
              <label class="col-form-label col-sm-3 text-md-right">选择收货地址</label>
              <div class="col-sm-9 col-md-6">
                <select class="form-control" name="address">
                  <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                      value="<?php echo e($address->id, false); ?>"><?php echo e($address->full_address, false); ?> <?php echo e($address->contact_name, false); ?> <?php echo e($address->contact_phone, false); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <span><a class="btn btn-primary " href="<?php echo e(route('addresses.create'), false); ?>">新增</a></span>
            </div>
            <div class="form-group row">
              <label class="col-form-label col-sm-3 text-md-right">备注</label>
              <div class="col-sm-9 col-md-7">
                <textarea name="remark" class="form-control" rows="3"></textarea>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-form-label col-sm-3 text-md-right">优惠券</label>
              <div class="col-sm-9 col-md-6">
                <input class="form-control" type="text" name="coupon">
              </div>
              <span>
                  <a id="check_coupon_code" class="btn btn-primary">检查</a>
                </span>
              <div class="form-text" id="discount_value"></div>
            </div>
            <div class="form-group">
              <div class="offset-sm-3 col-sm-3">
                <button type="button" class="btn btn-primary btn-create-order">提交订单</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
      $(document).ready(function () {

          //监听移除按钮
          $('.btn-remove').click(function () {
              var id = $(this).closest('tr').data('id')
              swal({
                  title: "确认移除？",
                  icon: 'warning',
                  buttons: ['取消', '确定'],
                  dangerMode: true
              })
                  .then(function (willDo) {
                      //点取消，willDo 值为false
                      if (!willDo) {
                          return;
                      }
                      axios.delete('cartItems/' + id)
                          .then(function () {
                              location.reload()
                          })
                  })
          })

          // 监听 全选/取消全选 单选框的变更事件
          // 获取单选框的选中状态
          // prop() 方法可以知道标签中是否包含某个属性，当单选框被勾选时，对应的标签就会新增一个 checked 的属性
          var checked = $(this).prop('checked');
          // 获取所有 name=select 并且不带有 disabled 属性的勾选框
          // 对于已经下架的商品我们不希望对应的勾选框会被选中，因此我们需要加上 :not([disabled]) 这个条件
          $('input[name=select][type=checkbox]:not([disabled])').each(function () {
              // 将其勾选状态设为与目标单选框一致
              $(this).prop('checked', checked);
          });


          //监听创建订单按钮
          $('.btn-create-order').click(function () {
              //构建请求参数，将用户地址和备注内容写入参数
              var data = {
                  address_id: $('form select[name=address]').val(),
                  items: [],
                  remark: $('textarea[name=remark]').val(),//备注
                  coupon: $('input[name=coupon]').val(),//优惠码
              }
              //遍历table中的所有tr data-id,取到sku id
              $('table tr[data-id]').each(function () {
                  //获取当前行的单选框
                  var checkbox = $(this).find('input[type=checkbox][name=select]');
                  //如果单选框没有被选中或者被禁用，就直接返回
                  if (checkbox.prop('disable') || !checkbox.prop('checked')) {
                      return;
                  }
                  //获取当前输入数量
                  var input = $(this).find('input[name=amount]');
                  //如果数量为0 或者不是数字，也返回
                  //isNan() is not a number
                  if (input.val() === 0 || isNaN(input.val())) {
                      return;
                  }
                  //把sku的数量和id存入到请求数据中
                  data.items.push({
                      id: $(this).data('id'),
                      amount: input.val(),
                  })
              })

              //发送请求
              axios.post('<?php echo e(route('orders.store'), false); ?>', data)
                  .then(function (response) {
                      swal('订单提交成功', '', 'success')
                      let id = response.data.id
                      location.href = '/orders/' + id

                  }, function (error) {
                      if (error.response.status === 422) {
                          // http 状态码为 422 代表用户输入校验失败
                          var html = '<div>';
                          _.each(error.response.data.errors, function (errors) {
                              _.each(errors, function (error) {
                                  html += error + '<br>';
                              })
                          });
                          html += '</div>';
                          swal({content: $(html)[0], icon: 'error'})
                      } else {
                          //资源禁止访问,或不存在,或系统错误
                          swal(error.response.data.msg, '', 'error')
                      }
                  })
          })

          //监听检查优惠券按钮
          $('#check_coupon_code').click(function () {
              //发送请求，检查优惠券，可用返回优惠券信息
              axios.post('<?php echo e(route('coupons.check'), false); ?>', {code: $('input[name=coupon]').val()})
                  .then(function (response) {
                      //可用（还没检查是否满足满减），先列出来
                      $('#discount_value').text(response.data.description)

                  }, function (error) {
                      //优惠券错误
                      swal(error.response.data.msg, '', 'error')
                      console.log(error.response.status)
                  })
          })
      })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/users/cart.blade.php ENDPATH**/ ?>