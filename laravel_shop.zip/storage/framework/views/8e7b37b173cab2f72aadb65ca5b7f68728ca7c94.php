<?php $__env->startSection('title', ($address->id? '修改' : '新增'). '收货地址'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row <?php echo e(route_class(), false); ?>">
    <div class="col-md-8 offset-md-2">

      <div class="card">
        <div class="card-header">
          <h2 class="text-center">
            <?php echo e(($address->id? '修改' : '新增'). '收货地址', false); ?>

          </h2>
        </div>
        <div class="card-body">
          
          <?php if(count($errors)>0): ?>
            <div class="alert alert-danger">
              <h4>发生错误：</h4>
              <ul>

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error, false); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </ul>
            </div>
          <?php endif; ?>
          
          <user-address-select inline-template>
            <?php if($address->id): ?>
              <form action="<?php echo e(route('addresses.update',$address->id), false); ?>" method="post">
                <?php echo e(method_field('PATCH'), false); ?>

                <?php else: ?>
                  <form action="<?php echo e(route('addresses.store'), false); ?>" method="post">
                    <?php endif; ?>
                    <?php echo e(csrf_field(), false); ?>

                    
                    
                    <select-district :init-value="<?php echo e(json_encode([old('province_name', $address->province_name), old('city_name',$address->city_name),
                old('district_name',$address->district_name)]), false); ?>"
                                     v-on:changed-address="onChangeAddress"></select-district>
                    <input type="hidden" name="province_name" v-model="province">
                    <input type="hidden" name="city_name" v-model="city">
                    <input type="hidden" name="district_name" v-model="district">
                    <div class="form-group row">
                      <label class="col-form-label col-sm-3 text-sm-right">区地址&nbsp;</label>
                      <div class="col-sm-9 form-control">
                        <p type="text">{{ address }}</p>
                      </div>
                    </div>

                    <div class="form-group row">
                      <label class="col-sm-3 text-sm-right">街道住所地址</label>
                      <input
                        type="text"
                        name="strict" id="" class="form-control col-sm-9" value="<?php echo e(old('strict', $address->strict), false); ?>">
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-3 text-sm-right">收货人</label>
                      <input
                        type="text"
                        name="contact_name" id="" class="form-control col-sm-9"
                        value="<?php echo e(old('contact_name', $address->contact_name), false); ?>">
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-3 text-sm-right">手机号</label>
                      <input
                        type="phone"
                        name="contact_phone" id="" class="form-control col-sm-9"
                        value="<?php echo e(old('contact_phone', $address->contact_phone), false); ?>">
                    </div>
                    <div class="form-group row text-center">
                      <div class="col-12">
                        <button type="submit" class="btn btn-primary">提交</button>
                      </div>
                    </div>
                  </form>
          </user-address-select>
        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/users/create_and_edit_address.blade.php ENDPATH**/ ?>