
<?php $__env->startSection('title', '订单详情'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-8 offset-lg-2">
      <div class="card">
        <div class="card-header"><h2>订单详情</h2></div>
        <div class="card-body">
          <table class="table">
            <thead>
            <tr>
              <th>商品信息</th>
              <th class="text-center">单价</th>
              <th class="text-center">数量</th>
              <th class="float-right item-amount">小计</th>
            </tr>
            </thead>
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="product-info">
                  <div class="preview">
                    <a target="_blank" href="<?php echo e(route('products.show',$item->product_id), false); ?>">
                      <img src="<?php echo e(asset('storage/'.$item->product->image), false); ?>" alt="商品封面">
                    </a>
                  </div>
                  <div>
                    <span class="product-title">
                      <a href="<?php echo e(route('products.show',$item->product_id), false); ?>"><?php echo e($item->product->title, false); ?></a>
                    </span>
                    <span class="sku-title"><?php echo e($item->productSku->title, false); ?></span>
                  </div>
                </td>
                <td class="sku-price text-center vertical-middle">￥<?php echo e($item->price, false); ?></td>
                <td class="sku-amount text-center vertical-middle"><?php echo e($item->amount, false); ?></td>
                <td class="item-amount text-right vertical-middle">
                  ￥<?php echo e(number_format($item->price * $item->amount, 2, '.', ''), false); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td colspan="4"></td>
            </tr>
          </table>

          <div class="order-bottom">
            <div class="order-info">
              <div class="line">
                <div class="line-label">
                  收货地址：
                </div>
                <div class="line-value"><?php echo e(join(' ',$order->address), false); ?></div>
              </div>
              <div class="line">
                <div class="line-label">
                  订单备注：
                </div>
                <div class="line-value"><?php echo e($order->remark?: '-', false); ?></div>
              </div>
              <div class="line">
                <div class="line-label">
                  订单编号：
                </div>
                <div class="line-value"><?php echo e($order->no, false); ?></div>
              </div>
              
              <?php if($order->paid_at): ?>

                <div class="line">
                  <div class="line-label">
                    物流状态：
                  </div>
                  <div class="line-value"><?php echo e(\App\Models\Order::$shipStatusMap[$order->ship_status], false); ?></div>
                </div>
                
                <?php if($order->ship_status != \App\Models\Order::SHIP_STATUS_PENDING): ?>
                  <div class="line">
                    <div class="line-label">
                      物流公司：
                    </div>
                    <div class="line-value"><?php echo e($order->ship_data['express_company'] ?: '', false); ?></div>
                  </div>
                  <div class="line">
                    <div class="line-label">
                      物流单号：
                    </div>
                    <div class="line-value"><?php echo e($order->ship_data['express_no'] ?: '', false); ?></div>
                  </div>
                <?php endif; ?>
                
                <?php if($order->paid_at && $order->refund_status !== \App\Models\Order::REFUND_STATUS_PENDING): ?>
                  <div class="line">
                    <div class="line-label">退款状态：</div>
                    <div class="line-value"><?php echo e(\App\Models\Order::$refundStatusMap[$order->refund_status], false); ?></div>
                  </div>
                  <div class="line">
                    <div class="line-label">退款理由：</div>
                    <div class="line-value"><?php echo e($order->extra['refund_reason'], false); ?></div>
                  </div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
            <div class="order-summary text-right">
              <!-- 展示优惠信息开始 -->
              <?php if($order->coupon): ?>
                <div class="text-primary">
                  <span>优惠信息：</span>
                  <div class="value"><?php echo e($order->coupon->description, false); ?></div>
                </div>
              <?php endif; ?>
            <!-- 展示优惠信息结束 -->
              <div class="total-amount">
                <span>订单总价：</span>
                <div class="value">￥<?php echo e($order->total_amount, false); ?></div>
              </div>
              <div>
                <span>订单状态</span>
                <div class="value">
                  <?php if($order->paid_at): ?>
                    <?php if($order->refund_status === \App\Models\Order::REFUND_STATUS_PENDING): ?>
                      已支付
                    <?php else: ?>
                      <?php echo e(\App\Models\Order::$refundStatusMap[$order->refund_status], false); ?>

                    <?php endif; ?>
                  <?php elseif($order->close): ?>
                    已关闭
                  <?php else: ?>
                    未支付
                  <?php endif; ?>
                </div>
              </div>
              <!-- 支付按钮开始 -->
              <?php if(!$order->paid_at && !$order->closed): ?>
                <div class="payment-buttons">
                  <a class="btn btn-primary btn-sm"
                     href="<?php echo e(route('payment.alipay', ['order' => $order->id]), false); ?>">支付宝支付</a>
                </div>
              <?php endif; ?>
            <!-- 支付按钮结束 -->
              
              <?php if($order->ship_status === \App\Models\Order::SHIP_STATUS_DELIVERED): ?>
                <div class="receive-button">
                  <button class="btn btn-sm btn-success">确认收货</button>
                </div>

              <?php endif; ?>

              
              <?php if($order->paid_at && $order->refund_status === \App\Models\Order::REFUND_STATUS_PENDING): ?>
                <div class="refund-button">
                  <button class="btn btn-sm btn-danger" id="btn-apply-refund">申请退款</button>
                </div>
              <?php endif; ?>
            </div>

          </div>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
      $(document).ready(function () {

          //确认收货按钮提交
          $('.receive-button button').click(function () {
              swal({
                  title: '你确定要收货吗？',
                  icon: 'warning',
                  dangerMode: true,
                  buttons: ['取消', '确认收货']
              }).then(function (willDo) {
                  if (!willDo) {
                      console.log(willDo)
                      return
                  }
                  //发送请求
                  axios.post('<?php echo e(route('orders.received', [$order->id]), false); ?>', {
                      _token: '<?php echo e(csrf_token(), false); ?>'
                  })
                      .then(function () {
                          //刷新页面
                          location.reload()
                      }, function (error) {
                          if (error.response.status === 401) {
                              swal('请登录后再操作', '', 'error')
                          } else if (error.response && (error.response.msg || error.response.messga)) {
                              //其他错误信息
                              swal(error.response.msg ? error.response.msg : error.response.message, '', 'error')
                          } else {
                              //系统挂了
                              swal('系统错误', '', 'error')
                          }
                      })
              })
          })

          //退款申请按钮提交
          $('#btn-apply-refund').click(function () {
              swal({
                  text: '请输入退款理由',
                  content: "input",
              }).then(function (input) {
                  // 当用户点击 swal 弹出框上的按钮时触发这个函数
                  if (!input) {
                      swal('退款理由不可空', '', 'error');
                      return;
                  }
                  // 请求退款接口
                  axios.post('<?php echo e(route('orders.refund.apply', [$order->id]), false); ?>', {reason: input})
                      .then(function () {
                          swal('申请退款成功', '', 'success').then(function () {
                              // 用户点击弹框上按钮时重新加载页面
                              location.reload();
                          });
                      });
              });
          });
      })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/laravel_shop/resources/views/users/order_show.blade.php ENDPATH**/ ?>