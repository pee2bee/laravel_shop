@extends('layouts.app')
@section('title','首页')
@section('content')


@stop
